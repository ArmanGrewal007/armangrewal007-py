# Steps to install

- `pip install armangrewal007`
- Type `armangrewal007` in your terminal to see my resume!
