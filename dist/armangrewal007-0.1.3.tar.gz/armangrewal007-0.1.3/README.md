# Steps to install

- USE THIS COMMAND TO GET THE LATEST PACKAGE, because I update it constantly `pip install --upgrade armangrewal007`
- Type `armangrewal007` in your terminal to see my resume!


> [!WARNING]
> Links and emojis will not be working for Windows users, because PowerShell does not support that (Switch to a better OS 😢)
